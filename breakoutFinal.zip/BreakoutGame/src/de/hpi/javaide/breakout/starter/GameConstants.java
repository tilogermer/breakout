package de.hpi.javaide.breakout.starter;

import java.awt.Point;

public interface GameConstants {
	int LIVES = 3;
	int SCREEN_X = 1200;
	int SCREEN_Y = 800;
	Point STARTPOSITION = new Point(SCREEN_X/2, SCREEN_Y/2);
}
